import PDFDocument from 'pdfkit';
import { Label } from '@prisma/client';
import { format } from 'date-fns';

function brDate(date: Date | null) {
  if (!date) return '-';
  return format(date, 'dd/MM/yyyy');
}

function labelTitle(type: string) {
  const map: Record<string, string> = {
    PRODUTO_ABERTO: 'ETIQUETA DE PRODUTO ABERTO',
    PRODUCAO: 'ETIQUETA DE PRODUÇÃO',
    DESCONGELAMENTO_DESSALGUE: 'ETIQUETA DE DESCONGELAMENTO/DESSALGUE',
    ARMAZENAMENTO_CARNES: 'ETIQUETA DE CARNES / RASTREABILIDADE',
    REEMBALAGEM: 'ETIQUETA DE REEMBALAGEM',
    AMOSTRAS: 'ETIQUETA DE AMOSTRA',
    NAO_CONFORME: 'ETIQUETA DE NÃO CONFORME',
    PRODUTO_QUIMICO: 'ETIQUETA DE PRODUTO QUÍMICO'
  };
  return map[type] || 'ETIQUETA';
}

export async function buildLabelPdf(label: Label): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margin: 30 });
    const chunks: Buffer[] = [];
    doc.on('data', (chunk: Buffer) => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    doc.fontSize(18).font('Helvetica-Bold').fillColor('#008f86').text('SafeKitchen Smart', { align: 'center' });
    doc.moveDown(0.3);
    doc.fontSize(12).fillColor('#333').text(labelTitle(label.type), { align: 'center' });
    doc.moveDown(1);

    const x = 55;
    const y = 105;
    const w = 485;
    const h = 270;
    doc.roundedRect(x, y, w, h, 12).strokeColor('#008f86').lineWidth(1.5).stroke();

    doc.fillColor('#008f86').rect(x, y, w, 38).fill();
    doc.fillColor('#fff').font('Helvetica-Bold').fontSize(16).text(label.productName, x + 16, y + 12, { width: w - 32 });

    doc.fillColor('#111').font('Helvetica').fontSize(10);
    let rowY = y + 58;
    const line = (labelText: string, value: string) => {
      doc.font('Helvetica-Bold').text(labelText, x + 16, rowY, { continued: true });
      doc.font('Helvetica').text(` ${value || '-'}`);
      rowY += 24;
    };

    line('Tipo:', labelTitle(label.type));
    line('Marca:', label.brand || '-');
    line('Fornecedor:', label.supplier || '-');
    line('Lote:', label.batch || '-');
    line('Conservação:', label.conservationMode);
    line('Aberto/Manipulado em:', brDate(label.openedAt));
    line('Válido até:', brDate(label.expiresAt));
    line('Quantidade:', label.quantity || '-');
    line('Responsável:', label.responsibleName);

    if (label.observations) {
      doc.moveDown(0.5);
      doc.font('Helvetica-Bold').text('Observações:', x + 16, rowY);
      doc.font('Helvetica').text(label.observations, x + 16, rowY + 14, { width: w - 32 });
    }

    doc.fontSize(8).fillColor('#555').text(`Gerado em ${brDate(label.createdAt)} pelo SafeKitchen Smart`, x, y + h + 18, { align: 'center' });
    doc.end();
  });
}
