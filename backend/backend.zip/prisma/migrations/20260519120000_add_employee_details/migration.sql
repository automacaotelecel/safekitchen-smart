ALTER TABLE "Employee" ADD COLUMN "role" TEXT;
ALTER TABLE "Employee" ADD COLUMN "phone" TEXT;
ALTER TABLE "Employee" ADD COLUMN "email" TEXT;