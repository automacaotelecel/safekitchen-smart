import { useEffect, useMemo, useState } from 'react';
import { ClipboardList, AlertTriangle, Clock3, ShieldCheck, Plus, History } from 'lucide-react';
import { Link } from 'react-router-dom';
import { api } from '../api/client';

type DashboardLabel = {
  id: string;
  productName: string;
  labelType: string;
  responsibleName?: string | null;
  expiresAt?: string | null;
};

type DashboardResponse = {
  stats: {
    total: number;
    active: number;
    expired: number;
    noExpiry: number;
  };
  recentLabels: DashboardLabel[];
};

function formatDate(value?: string | null) {
  if (!value) return 'Sem validade';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Sem validade';
  return date.toLocaleDateString('pt-BR');
}

function labelTypeName(type: string) {
  const map: Record<string, string> = {
    OPEN_PRODUCT: 'Produto aberto',
    PRODUCTION: 'Produção',
    THAWING: 'Descongelamento',
    MEAT_STORAGE: 'Armazenamento',
    REPACKAGING: 'Reembalagem',
    SAMPLE: 'Amostras',
    NON_CONFORMING: 'Não conforme',
    CHEMICAL: 'Produto químico'
  };
  return map[type] ?? type;
}

export function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<DashboardResponse>({
    stats: { total: 0, active: 0, expired: 0, noExpiry: 0 },
    recentLabels: []
  });

  useEffect(() => {
    async function load() {
      try {
        const response = await api<DashboardResponse>('/api/labels/dashboard');
        setData(response);
      } catch {
        setData({
          stats: { total: 0, active: 0, expired: 0, noExpiry: 0 },
          recentLabels: []
        });
      } finally {
        setLoading(false);
      }
    }

    load();
  }, []);

  const cards = useMemo(
    () => [
      {
        label: 'Etiquetas',
        value: data.stats.total,
        description: 'Total gerado',
        icon: ClipboardList
      },
      {
        label: 'Ativas',
        value: data.stats.active,
        description: 'Dentro da validade',
        icon: ShieldCheck
      },
      {
        label: 'Vencidas',
        value: data.stats.expired,
        description: 'Precisam de atenção',
        icon: AlertTriangle
      },
      {
        label: 'Sem validade',
        value: data.stats.noExpiry,
        description: 'Itens sem vencimento',
        icon: Clock3
      }
    ],
    [data]
  );

  return (
    <div className="space-y-5">
      <section className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-sm md:p-6">
        <div className="flex flex-col gap-5 xl:flex-row xl:items-start xl:justify-between">
          <div className="max-w-3xl">
            <p className="text-xs font-extrabold uppercase tracking-[0.26em] text-safe-green">
              Dashboard
            </p>
            <h1 className="mt-2 text-3xl font-black leading-tight text-safe-dark md:text-4xl">
              Controle sanitário da operação
            </h1>
            <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-600 md:text-base">
              Acompanhe rapidamente a situação das etiquetas, validade dos produtos e
              últimos registros gerados pela equipe.
            </p>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row">
            <Link
              to="/nova-etiqueta"
              className="inline-flex items-center justify-center gap-2 rounded-2xl bg-safe-green px-5 py-3 text-sm font-bold text-white shadow-sm transition hover:brightness-95"
            >
              <Plus size={18} />
              Nova etiqueta
            </Link>

            <Link
              to="/historico"
              className="inline-flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-slate-50 px-5 py-3 text-sm font-bold text-safe-dark transition hover:bg-slate-100"
            >
              <History size={18} />
              Ver histórico
            </Link>
          </div>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.label}
              className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-[11px] font-extrabold uppercase tracking-[0.25em] text-slate-400">
                    {card.label}
                  </p>
                  <p className="mt-3 text-4xl font-black text-safe-dark">
                    {loading ? '—' : card.value}
                  </p>
                </div>

                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-safe-soft text-safe-green">
                  <Icon size={22} />
                </div>
              </div>

              <p className="mt-4 text-sm font-medium text-slate-500">{card.description}</p>
            </div>
          );
        })}
      </section>

      <section className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-sm md:p-6">
        <div className="mb-4 flex items-center justify-between gap-3">
          <div>
            <p className="text-xs font-extrabold uppercase tracking-[0.26em] text-safe-green">
              Operação
            </p>
            <h2 className="mt-1 text-2xl font-black text-safe-dark">Últimas etiquetas</h2>
          </div>

          <Link
            to="/nova-etiqueta"
            className="rounded-2xl bg-safe-green px-4 py-2 text-sm font-bold text-white shadow-sm"
          >
            Gerar nova
          </Link>
        </div>

        <div className="space-y-3">
          {loading ? (
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-500">
              Carregando etiquetas...
            </div>
          ) : data.recentLabels.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-5 text-sm text-slate-500">
              Nenhuma etiqueta gerada até o momento.
            </div>
          ) : (
            data.recentLabels.map((label) => (
              <div
                key={label.id}
                className="flex flex-col gap-3 rounded-2xl border border-slate-200 bg-slate-50 p-4 md:flex-row md:items-center md:justify-between"
              >
                <div>
                  <p className="text-lg font-extrabold text-safe-dark">{label.productName}</p>
                  <p className="mt-1 text-sm text-slate-600">
                    {labelTypeName(label.labelType)}
                    {label.responsibleName ? ` • Responsável: ${label.responsibleName}` : ''}
                  </p>
                </div>

                <div className="self-start rounded-full bg-white px-4 py-2 text-sm font-bold text-safe-dark shadow-sm">
                  Validade: {formatDate(label.expiresAt)}
                </div>
              </div>
            ))
          )}
        </div>
      </section>
    </div>
  );
}