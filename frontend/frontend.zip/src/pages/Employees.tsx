import { useEffect, useMemo, useState } from 'react';
import {
  BadgeCheck,
  Mail,
  Pencil,
  Phone,
  Plus,
  Search,
  Trash2,
  UserRound,
  UserX,
} from 'lucide-react';
import { api } from '../api/client';

type Employee = {
  id: string;
  name: string;
  role?: string | null;
  shift?: string | null;
  phone?: string | null;
  email?: string | null;
  active: boolean;
  createdAt?: string;
};

type EmployeeForm = {
  name: string;
  role: string;
  shift: string;
  phone: string;
  email: string;
};

const initialForm: EmployeeForm = {
  name: '',
  role: '',
  shift: '',
  phone: '',
  email: '',
};

export function Employees() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [search, setSearch] = useState('');
  const [showInactive, setShowInactive] = useState(false);
  const [form, setForm] = useState<EmployeeForm>(initialForm);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');

  async function loadEmployees() {
    try {
      setLoading(true);
      const response = await api<any>('/api/employees');

      const raw =
        (Array.isArray(response?.data) && response.data) ||
        (Array.isArray(response?.employees) && response.employees) ||
        [];

      setEmployees(raw);
    } catch (error) {
      console.error('Erro ao carregar funcionários:', error);
      setEmployees([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadEmployees();
  }, []);

  const activeCount = employees.filter((item) => item.active).length;
  const inactiveCount = employees.filter((item) => !item.active).length;

  const filteredEmployees = useMemo(() => {
    const term = search.trim().toLowerCase();

    return employees.filter((employee) => {
      const statusOk = showInactive ? true : employee.active;

      const textOk =
        !term ||
        employee.name?.toLowerCase().includes(term) ||
        employee.role?.toLowerCase().includes(term) ||
        employee.shift?.toLowerCase().includes(term) ||
        employee.phone?.toLowerCase().includes(term) ||
        employee.email?.toLowerCase().includes(term);

      return statusOk && textOk;
    });
  }, [employees, search, showInactive]);

  function updateField<K extends keyof EmployeeForm>(field: K, value: EmployeeForm[K]) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();

    if (!form.name.trim()) {
      setMessage('Informe o nome do funcionário.');
      return;
    }

    try {
      setSaving(true);
      setMessage('');

      const payload = {
        name: form.name.trim(),
        role: form.role.trim() || null,
        shift: form.shift.trim() || null,
        phone: form.phone.trim() || null,
        email: form.email.trim() || null,
      };

      if (editingId) {
        await api(`/api/employees/${editingId}`, {
          method: 'PATCH',
          body: JSON.stringify(payload),
        });
        setMessage('Funcionário atualizado com sucesso.');
      } else {
        await api('/api/employees', {
          method: 'POST',
          body: JSON.stringify(payload),
        });
        setMessage('Funcionário cadastrado com sucesso.');
      }

      setForm(initialForm);
      setEditingId(null);
      await loadEmployees();
    } catch (error) {
      console.error(error);
      setMessage('Erro ao salvar funcionário.');
    } finally {
      setSaving(false);
    }
  }

  function handleEdit(employee: Employee) {
    setEditingId(employee.id);
    setForm({
      name: employee.name ?? '',
      role: employee.role ?? '',
      shift: employee.shift ?? '',
      phone: employee.phone ?? '',
      email: employee.email ?? '',
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function toggleActive(employee: Employee) {
    try {
      await api(`/api/employees/${employee.id}`, {
        method: 'PATCH',
        body: JSON.stringify({
          active: !employee.active,
        }),
      });

      await loadEmployees();
    } catch (error) {
      console.error(error);
      setMessage('Erro ao alterar status do funcionário.');
    }
  }

  async function removeEmployee(employee: Employee) {
    const confirmed = window.confirm(`Deseja remover "${employee.name}"?`);
    if (!confirmed) return;

    try {
      await api(`/api/employees/${employee.id}`, {
        method: 'DELETE',
      });

      if (editingId === employee.id) {
        setEditingId(null);
        setForm(initialForm);
      }

      await loadEmployees();
      setMessage('Funcionário removido com sucesso.');
    } catch (error) {
      console.error(error);
      setMessage('Erro ao remover funcionário.');
    }
  }

  return (
    <div className="space-y-6">
      <section className="grid gap-4 xl:grid-cols-[1fr_340px]">
        <div className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-soft dark:border-white/10 dark:bg-[#202020]">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.26em] text-safe-green">
                Equipe
              </p>
              <h1 className="mt-2 text-3xl font-black text-safe-dark dark:text-white">
                Funcionários
              </h1>
              <p className="mt-2 text-sm font-medium text-slate-500 dark:text-slate-300">
                Cadastre responsáveis para aparecer nas etiquetas e controlar quem está ativo.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="rounded-2xl border border-slate-200 bg-slate-50 px-5 py-4 text-center dark:border-white/10 dark:bg-[#151515]">
                <p className="text-2xl font-black text-safe-dark dark:text-white">{activeCount}</p>
                <p className="text-xs font-bold uppercase tracking-widest text-slate-500">
                  Ativos
                </p>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-slate-50 px-5 py-4 text-center dark:border-white/10 dark:bg-[#151515]">
                <p className="text-2xl font-black text-safe-dark dark:text-white">
                  {inactiveCount}
                </p>
                <p className="text-xs font-bold uppercase tracking-widest text-slate-500">
                  Inativos
                </p>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-slate-50 px-5 py-4 text-center dark:border-white/10 dark:bg-[#151515]">
                <p className="text-2xl font-black text-safe-dark dark:text-white">
                  {employees.length}
                </p>
                <p className="text-xs font-bold uppercase tracking-widest text-slate-500">
                  Total
                </p>
              </div>
            </div>
          </div>

          <div className="mt-5 flex flex-col gap-3 lg:flex-row">
            <div className="relative flex-1">
              <Search
                size={18}
                className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"
              />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Buscar por nome, função, turno, telefone ou e-mail..."
                className="w-full rounded-2xl border border-slate-200 bg-slate-50 py-3 pl-11 pr-4 text-sm font-medium outline-none transition focus:border-safe-green focus:bg-white dark:border-white/10 dark:bg-[#151515] dark:text-white"
              />
            </div>

            <button
              type="button"
              onClick={() => setShowInactive((prev) => !prev)}
              className="rounded-2xl border border-slate-200 px-4 py-3 text-sm font-bold text-safe-dark transition hover:bg-slate-50 dark:border-white/10 dark:text-white dark:hover:bg-white/5"
            >
              {showInactive ? 'Ocultar inativos' : 'Mostrar inativos'}
            </button>
          </div>

          {message && (
            <div className="mt-4 rounded-2xl bg-safe-soft px-4 py-3 text-sm font-bold text-safe-dark">
              {message}
            </div>
          )}
        </div>

        <div className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-soft dark:border-white/10 dark:bg-[#202020]">
          <div className="flex items-center gap-2">
            <Plus size={18} className="text-safe-dark dark:text-white" />
            <h2 className="text-2xl font-black text-safe-dark dark:text-white">
              {editingId ? 'Editar funcionário' : 'Novo funcionário'}
            </h2>
          </div>

          <p className="mt-2 text-sm font-medium text-slate-500 dark:text-slate-300">
            Estes dados ajudam na rastreabilidade das etiquetas.
          </p>

          <form onSubmit={handleSubmit} className="mt-5 space-y-4">
            <div>
              <label className="mb-2 block text-sm font-bold text-safe-dark dark:text-white">
                Nome
              </label>
              <input
                value={form.name}
                onChange={(e) => updateField('name', e.target.value)}
                className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-safe-green focus:bg-white dark:border-white/10 dark:bg-[#151515] dark:text-white"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-bold text-safe-dark dark:text-white">
                Função/cargo
              </label>
              <input
                value={form.role}
                onChange={(e) => updateField('role', e.target.value)}
                placeholder="Ex.: Cozinha, Nutrição, Estoque..."
                className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-safe-green focus:bg-white dark:border-white/10 dark:bg-[#151515] dark:text-white"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-bold text-safe-dark dark:text-white">
                Turno
              </label>
              <select
                value={form.shift}
                onChange={(e) => updateField('shift', e.target.value)}
                className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-safe-green focus:bg-white dark:border-white/10 dark:bg-[#151515] dark:text-white"
              >
                <option value="">Selecione</option>
                <option value="Manhã">Manhã</option>
                <option value="Tarde">Tarde</option>
                <option value="Noite">Noite</option>
                <option value="Integral">Integral</option>
                <option value="Escala 12x36">Escala 12x36</option>
                <option value="Outro">Outro</option>
              </select>
            </div>

            <div>
              <label className="mb-2 block text-sm font-bold text-safe-dark dark:text-white">
                Telefone
              </label>
              <input
                value={form.phone}
                onChange={(e) => updateField('phone', e.target.value)}
                placeholder="Opcional"
                className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-safe-green focus:bg-white dark:border-white/10 dark:bg-[#151515] dark:text-white"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-bold text-safe-dark dark:text-white">
                E-mail
              </label>
              <input
                value={form.email}
                onChange={(e) => updateField('email', e.target.value)}
                placeholder="Opcional"
                className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-safe-green focus:bg-white dark:border-white/10 dark:bg-[#151515] dark:text-white"
              />
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full rounded-2xl bg-safe-green px-4 py-3 text-sm font-bold text-white shadow-lg transition hover:brightness-105 disabled:opacity-60"
            >
              {saving ? 'Salvando...' : editingId ? 'Salvar alterações' : 'Salvar funcionário'}
            </button>

            {editingId && (
              <button
                type="button"
                onClick={() => {
                  setEditingId(null);
                  setForm(initialForm);
                }}
                className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm font-bold text-safe-dark transition hover:bg-slate-50 dark:border-white/10 dark:text-white dark:hover:bg-white/5"
              >
                Cancelar edição
              </button>
            )}
          </form>
        </div>
      </section>

      <section className="grid gap-4 xl:grid-cols-2">
        {loading ? (
          <div className="col-span-full rounded-[28px] border border-dashed border-slate-200 bg-white p-8 text-center text-sm font-medium text-slate-500 shadow-soft dark:border-white/10 dark:bg-[#202020] dark:text-slate-300">
            Carregando funcionários...
          </div>
        ) : filteredEmployees.length === 0 ? (
          <div className="col-span-full rounded-[28px] border border-dashed border-slate-200 bg-white p-8 text-center text-sm font-medium text-slate-500 shadow-soft dark:border-white/10 dark:bg-[#202020] dark:text-slate-300">
            Nenhum funcionário encontrado.
          </div>
        ) : (
          filteredEmployees.map((employee) => (
            <div
              key={employee.id}
              className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-soft dark:border-white/10 dark:bg-[#202020]"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex gap-4">
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-safe-soft text-safe-green">
                    <UserRound size={24} />
                  </div>

                  <div>
                    <h3 className="text-2xl font-black text-safe-dark dark:text-white">
                      {employee.name}
                    </h3>

                    <p className="text-sm font-bold text-slate-500 dark:text-slate-300">
                      {employee.role || 'Sem função cadastrada'}
                    </p>

                    <div className="mt-2 flex flex-wrap gap-2">
                      {employee.shift && (
                        <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-600 dark:bg-[#151515] dark:text-slate-300">
                          Turno: {employee.shift}
                        </span>
                      )}

                      <span
                        className={`rounded-full px-3 py-1 text-xs font-bold ${
                          employee.active
                            ? 'bg-emerald-100 text-emerald-700'
                            : 'bg-amber-100 text-amber-700'
                        }`}
                      >
                        {employee.active ? 'ATIVO' : 'INATIVO'}
                      </span>
                    </div>
                  </div>
                </div>

                {employee.active ? (
                  <BadgeCheck className="text-safe-green" size={22} />
                ) : (
                  <UserX className="text-amber-500" size={22} />
                )}
              </div>

              <div className="mt-4 space-y-2 text-sm text-slate-600 dark:text-slate-300">
                <div className="flex items-center gap-2">
                  <Phone size={16} />
                  <span>{employee.phone || 'Sem contato cadastrado.'}</span>
                </div>

                <div className="flex items-center gap-2">
                  <Mail size={16} />
                  <span>{employee.email || 'Sem e-mail cadastrado.'}</span>
                </div>
              </div>

              <div className="mt-5 grid gap-2 sm:grid-cols-3">
                <button
                  type="button"
                  onClick={() => handleEdit(employee)}
                  className="inline-flex items-center justify-center gap-2 rounded-2xl border border-slate-200 px-4 py-3 text-sm font-bold text-safe-dark transition hover:bg-slate-50 dark:border-white/10 dark:text-white dark:hover:bg-white/5"
                >
                  <Pencil size={16} />
                  Editar
                </button>

                <button
                  type="button"
                  onClick={() => toggleActive(employee)}
                  className="inline-flex items-center justify-center gap-2 rounded-2xl bg-amber-50 px-4 py-3 text-sm font-bold text-amber-700 transition hover:bg-amber-100"
                >
                  <UserX size={16} />
                  {employee.active ? 'Inativar' : 'Ativar'}
                </button>

                <button
                  type="button"
                  onClick={() => removeEmployee(employee)}
                  className="inline-flex items-center justify-center gap-2 rounded-2xl bg-red-50 px-4 py-3 text-sm font-bold text-red-600 transition hover:bg-red-100"
                >
                  <Trash2 size={16} />
                  Remover
                </button>
              </div>
            </div>
          ))
        )}
      </section>
    </div>
  );
}