import { useEffect, useMemo, useState } from 'react';
import { CheckSquare, Printer, RefreshCcw, Search, Square } from 'lucide-react';
import { api } from '../api/client';

type LabelItem = {
  id: string;
  productName: string;
  labelType: string;
  responsibleName?: string | null;
  expiresAt?: string | null;
  createdAt?: string | null;
};

function formatDate(value?: string | null) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleDateString('pt-BR');
}

function labelTypeText(type: string) {
  const map: Record<string, string> = {
    OPEN_PRODUCT: 'Produto aberto',
    PRODUCTION: 'Produção',
    THAWING: 'Descongelamento/dessalgue',
    MEAT_STORAGE: 'Armazenamento de carnes',
    REPACKAGING: 'Reembalagem',
    SAMPLE: 'Amostras',
    NON_CONFORMING: 'Não conforme',
    CHEMICAL: 'Produto químico',
  };

  return map[type] ?? type;
}

export function PrintQueue() {
  const [items, setItems] = useState<LabelItem[]>([]);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  async function loadItems() {
    try {
      setLoading(true);

      const response = await api<any>('/api/labels?limit=100');

      const raw =
        (Array.isArray(response?.data) && response.data) ||
        (Array.isArray(response?.data?.labels) && response.data.labels) ||
        (Array.isArray(response?.labels) && response.labels) ||
        [];

      setItems(raw);
    } catch (error) {
      console.error('Erro ao carregar etiquetas para impressão:', error);
      setItems([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadItems();
  }, []);

  const filteredItems = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return items;

    return items.filter((item) => {
      return (
        item.productName?.toLowerCase().includes(term) ||
        item.labelType?.toLowerCase().includes(term) ||
        item.responsibleName?.toLowerCase().includes(term)
      );
    });
  }, [items, search]);

  const allVisibleSelected =
    filteredItems.length > 0 &&
    filteredItems.every((item) => selectedIds.includes(item.id));

  function toggleItem(id: string) {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((itemId) => itemId !== id) : [...prev, id]
    );
  }

  function toggleSelectAllVisible() {
    if (allVisibleSelected) {
      setSelectedIds((prev) =>
        prev.filter((id) => !filteredItems.some((item) => item.id === id))
      );
      return;
    }

    setSelectedIds((prev) => {
      const merged = new Set([...prev, ...filteredItems.map((item) => item.id)]);
      return Array.from(merged);
    });
  }

  function printOne(id: string) {
    const apiBase = import.meta.env.VITE_API_URL || 'http://localhost:3333';
    window.open(`${apiBase}/api/labels/${id}/pdf`, '_blank');
  }

  function printSelected() {
    if (!selectedIds.length) return;

    const apiBase = import.meta.env.VITE_API_URL || 'http://localhost:3333';

    selectedIds.forEach((id) => {
      window.open(`${apiBase}/api/labels/${id}/pdf`, '_blank');
    });
  }

  return (
    <div className="space-y-6">
      <section className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-soft dark:border-white/10 dark:bg-[#202020]">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.26em] text-safe-green">
              Impressão
            </p>
            <h1 className="mt-2 text-3xl font-black text-safe-dark dark:text-white">
              Central de impressão
            </h1>
            <p className="mt-2 text-sm font-medium text-slate-500 dark:text-slate-300">
              Selecione uma ou mais etiquetas para reimpressão.
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={loadItems}
              className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 px-4 py-3 text-sm font-bold text-slate-700 transition hover:bg-slate-50 dark:border-white/10 dark:text-white dark:hover:bg-white/5"
            >
              <RefreshCcw size={16} />
              Atualizar
            </button>

            <button
              type="button"
              onClick={printSelected}
              disabled={!selectedIds.length}
              className="inline-flex items-center gap-2 rounded-2xl bg-safe-green px-4 py-3 text-sm font-bold text-white shadow-lg transition hover:brightness-105 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <Printer size={16} />
              Imprimir selecionadas ({selectedIds.length})
            </button>
          </div>
        </div>

        <div className="mt-5 relative">
          <Search
            size={18}
            className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"
          />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por produto, tipo ou responsável..."
            className="w-full rounded-2xl border border-slate-200 bg-slate-50 py-3 pl-11 pr-4 text-sm font-medium outline-none transition focus:border-safe-green focus:bg-white dark:border-white/10 dark:bg-[#151515] dark:text-white"
          />
        </div>
      </section>

      <section className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-soft dark:border-white/10 dark:bg-[#202020]">
        <div className="mb-4 flex items-center justify-between gap-3">
          <div>
            <h2 className="text-xl font-black text-safe-dark dark:text-white">
              Etiquetas disponíveis
            </h2>
            <p className="text-sm text-slate-500 dark:text-slate-300">
              {filteredItems.length} resultado(s)
            </p>
          </div>

          <button
            type="button"
            onClick={toggleSelectAllVisible}
            className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 px-4 py-2 text-sm font-bold text-slate-700 transition hover:bg-slate-50 dark:border-white/10 dark:text-white dark:hover:bg-white/5"
          >
            {allVisibleSelected ? <CheckSquare size={16} /> : <Square size={16} />}
            {allVisibleSelected ? 'Desmarcar visíveis' : 'Marcar visíveis'}
          </button>
        </div>

        {loading ? (
          <div className="rounded-2xl border border-dashed border-slate-200 p-8 text-center text-sm font-medium text-slate-500 dark:border-white/10 dark:text-slate-300">
            Carregando etiquetas...
          </div>
        ) : filteredItems.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-200 p-8 text-center text-sm font-medium text-slate-500 dark:border-white/10 dark:text-slate-300">
            Nenhuma etiqueta encontrada.
          </div>
        ) : (
          <div className="space-y-3">
            {filteredItems.map((item) => {
              const selected = selectedIds.includes(item.id);

              return (
                <div
                  key={item.id}
                  className={`flex flex-col gap-4 rounded-2xl border p-4 transition lg:flex-row lg:items-center lg:justify-between ${
                    selected
                      ? 'border-safe-green bg-safe-soft/40'
                      : 'border-slate-200 bg-white dark:border-white/10 dark:bg-[#151515]'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <input
                      type="checkbox"
                      checked={selected}
                      onChange={() => toggleItem(item.id)}
                      className="mt-1 h-4 w-4 rounded border-slate-300 text-safe-green focus:ring-safe-green"
                    />

                    <div>
                      <p className="text-lg font-black text-safe-dark dark:text-white">
                        {item.productName || 'Sem nome'}
                      </p>
                      <p className="text-sm font-medium text-slate-500 dark:text-slate-300">
                        {labelTypeText(item.labelType)}
                      </p>

                      <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs font-semibold text-slate-500 dark:text-slate-400">
                        <span>Responsável: {item.responsibleName || '—'}</span>
                        <span>Validade: {formatDate(item.expiresAt)}</span>
                        <span>Criada em: {formatDate(item.createdAt)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => printOne(item.id)}
                      className="rounded-2xl border border-slate-200 px-4 py-2 text-sm font-bold text-slate-700 transition hover:bg-slate-50 dark:border-white/10 dark:text-white dark:hover:bg-white/5"
                    >
                      Abrir PDF
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        if (!selected) toggleItem(item.id);
                        setTimeout(() => printOne(item.id), 80);
                      }}
                      className="rounded-2xl bg-safe-green px-4 py-2 text-sm font-bold text-white shadow-sm transition hover:brightness-105"
                    >
                      Imprimir
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}